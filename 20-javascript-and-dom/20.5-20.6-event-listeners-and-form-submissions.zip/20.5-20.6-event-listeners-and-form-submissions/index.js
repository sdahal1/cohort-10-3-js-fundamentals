/* ~~~~~~~~~~~~~~~~~~~~~~~~ 20.5 Event Listeners ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
function expandArticleBody() {
    
}

function crossOffArticle() {
    
}
  
  
  
  
  /* ~~~~~~~~~~~~~~~~~~~~~~~~ 20.6 form submissions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  
function main() {
    expandArticleBody();
    crossOffArticle();
}
  